# Ambari安装部署

## 1 SUDO权限及机器名标准化

```
使用root用户登录：
1）添加用户hadoop
groupadd hadoop
useradd -g hadoop hadoop
passwd hadoop dtsw1234
2）sudo权限配置
chmod u+w /etc/sudoers
vim /etc/sudoers
...
hadoop	ALL=(ALL)	NOPASSWD:ALL
...
chmod u-w /etc/sudoers
【注：更改完成后记得关闭写权限，sudoers修改注意位置，不可直接加至末尾或开头】

使用hadoop用户，机器名标准化
sudo hostnamectl set-hostname dtsw-001
sudo vim /etc/hosts
172.18.2.29 dtsw-001.hadoop dtsw-001
172.18.2.11 dtsw-002.hadoop dtsw-002
172.18.2.37 dtsw-003.hadoop dtsw-003
172.18.2.19 dtsw-004.hadoop dtsw-004
172.18.2.10 dtsw-005.hadoop dtsw-005
【注：ambari配置机器列表时，必须配置全域名FQDN】
```

## 2 SSH无密码登录

```
dtsw-001上hadoop用户执行：
ssh-keygen -t rsa
ssh-copy-id -i  ~/.ssh/id_rsa.pub hadoop@dtsw-001.hadoop
ssh-copy-id -i  ~/.ssh/id_rsa.pub hadoop@dtsw-002.hadoop
ssh-copy-id -i  ~/.ssh/id_rsa.pub hadoop@dtsw-003.hadoop
ssh-copy-id -i  ~/.ssh/id_rsa.pub hadoop@dtsw-004.hadoop
ssh-copy-id -i  ~/.ssh/id_rsa.pub hadoop@dtsw-005.hadoop
执行完后，dtsw-001上的用户hadoop就可以ssh到dtsw-00[1-5]
【注：一般而言只需要server节点ssh到agent即可，如果需要agent节点ssh到server节点，则需安装上诉步骤配置】
```

## 3 安装元数据库（MySQL为例）

```
wget http://repo.mysql.com/mysql57-community-release-el7-8.noarch.rpm
sudo rpm -ivh mysql57-community-release-el7-8.noarch.rpm  --nodeps --force
sudo yum install mysql-server
sudo systemctl start mysqld
sudo systemctl enable mysqld 
```

找到初始密码，设置新密码

```
grep 'temporary password' /var/log/mysqld.log
mysql -u root -p
mysql> Enter password: （输入刚才查询到的随机密码）
mysql> SET PASSWORD FOR 'root'@'dtsw-001'= "dtsw1234";
mysql>GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY 'dtsw1234' WITH GRANT OPTION;
mysql>FLUSH PRIVILEGES;
```

创建ambari元数据库

```
create database ambari character set utf8 ; 
CREATE USER 'ambari'@'%'IDENTIFIED BY 'bigdata';
GRANT ALL PRIVILEGES ON *.* TO 'ambari'@'%';
FLUSH PRIVILEGES;
```

如果装hive的话，创建hive元数据库

```
create database hive character set utf8 ; 
CREATE USER 'hive'@'%'IDENTIFIED BY '123456';
GRANT ALL PRIVILEGES ON *.* TO 'hive'@'%';
FLUSH PRIVILEGES;
```

安装mysql jdbc驱动

```
sudo yum install mysql-connector-java
```

## 4  安装Ambari

### 4.1 安装ambari-server

```

sudo yum install ambari-server
```

### 4.2 ambari-server设置

```
sudo ambari-server setup
Customize user account for ambari-server daemon [y/n] (n)? 输入y
Enter user account for ambari-server daemon (root):ambariAdjusting ambari-server permissions and ownership... 输入ambari
Checking JDK...
[1] Oracle JDK 1.8 + Java Cryptography Extension (JCE) Policy Files 8
[2] Oracle JDK 1.7 + Java Cryptography Extension (JCE) Policy Files 7
[3] Custom JDK
==============================================================================
Enter choice (1):3
WARNING: JDK must be installed on all hosts and JAVA_HOME must be valid on all hosts.
WARNING: JCE Policy files are required for configuring Kerberos security. If you plan to use Kerberos,please make sure JCE Unlimited Strength Jurisdiction Policy Files are valid on all hosts.
Path to JAVA_HOME: /opt/java/jdk1.8.0_121/opt/jdk/jdk1.8.0_121

Configuring database...
Enter advanced database configuration [y/n] (n)?  属于y
Configuring database...
==============================================================================
Choose one of the following options:
[1] - PostgreSQL (Embedded)
[2] - Oracle
[3] - MySQL / MariaDB
[4] - PostgreSQL
[5] - Microsoft SQL Server (Tech Preview)
[6] - SQL Anywhere
[7] - BDB
==============================================================================
Enter choice (1): 3
Enter choice (1): 3
Hostname (localhost):dtsw-001
Port (3306):
Database name (ambari):
Username (ambari):
Enter Database Password (bigdata):
Re-enter password:
Configuring ambari database...
Configuring remote database connection properties...
WARNING: Before starting Ambari Server, you must run the following DDL against the database to create the schema: /var/lib/ambari-server/resources/Ambari-DDL-MySQL-CREATE.sql
Proceed with configuring remote database connection properties [y/n] (y)? y
Extracting system views...
....ambari-admin-2.6.2.0.155.jar
.......
Adjusting ambari-server permissions and ownership...
Ambari Server 'setup' completed successfully.
```

### 4.3 将ambari数据库导入

```
mysql -uambari -pbigdata
mysql> use ambari;
Database changed
mysql> source /var/lib/ambari-server/resources/Ambari-DDL-MySQL-CREATE.sql
```

### 4.4 启动ambari-server

```
sudo ambari-server start
```

## 5 安装向导

![image-20200811164644218](E:\Typora\Ambari\image-20200811164644218.png)

![image-20200811164659699](E:\Typora\Ambari\image-20200811164659699.png)

![image-20200811164724717](E:\Typora\Ambari\image-20200811164724717.png)

![](E:\Typora\Ambari\image-20200811164750686.png)

![image-20200811164841618](E:\Typora\Ambari\image-20200811164841618.png)

```
http://172.18.2.29:81/repo/HDP/centos7/3.1.0.0-78/HDP-3.1.0.0-78.xml
http://172.18.2.29:81/repo/HDP/centos7/3.1.0.0-78
http://172.18.2.29:81/repo/HDP-UTILS/centos7/1.1.0.22
http://172.18.2.29:81/repo/HDP-GPL/centos7/3.1.0.0-78
```

![image-20200811164945635](E:\Typora\Ambari\image-20200811164945635.png)

![image-20200811165027962](E:\Typora\Ambari\image-20200811165027962.png)

![image-20200811165038361](E:\Typora\Ambari\image-20200811165038361.png)

![image-20200811184319957](E:\Typora\Ambari\image-20200811184319957.png)

![image-20200811184346756](E:\Typora\Ambari\image-20200811184346756.png)

![image-20200811184407062](E:\Typora\Ambari\image-20200811184407062.png)

![image-20200811184421222](E:\Typora\Ambari\image-20200811184421222.png)

![image-20200811184436174](E:\Typora\Ambari\image-20200811184436174.png)

![image-20200811184446407](E:\Typora\Ambari\image-20200811184446407.png)

![image-20200811184500580](E:\Typora\Ambari\image-20200811184500580.png)

![image-20200811184516239](E:\Typora\Ambari\image-20200811184516239.png)

![image-20200811184553462](E:\Typora\Ambari\image-20200811184553462.png)

![image-20200811184955173](E:\Typora\Ambari\image-20200811184955173.png)

![image-20200811185035928](E:\Typora\Ambari\image-20200811185035928.png)



异常1：

```
Error: Sudo command is not available. Please install the sudo command.
解决：
代码中会通过python调用rpm -qa | grep -e '^sudo\-'，经查看，虽然节点可以使用sudo命令，但是内置的，并没有查到sudo-相关包，直接使用sudo yum install sudo安装就可解决。
```

异常2：

```
SSLError: Failed to connect. Please check openssl library versions.
解决：
修改/etc/ambari-agent/conf/ambari-agent.ini
[security]
force_https_protocol=PROTOCOL_TLSv1_2
```

异常3：

```
Registering with the server...
Registration with the server failed.
解决：
由于之前装过本台节点为agent，更改dtsw-001.hadoop为dtsw-003.hadoop
修改 sudo vim /etc/ambari-agent/conf/ambari-agent.ini
[server]
hostname=dtsw-003.hadoop
```

