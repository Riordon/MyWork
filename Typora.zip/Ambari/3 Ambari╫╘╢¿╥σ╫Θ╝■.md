# **Stacks and Services**

## 0 术语

| 术语      | 描述                                                         |
| :-------- | ------------------------------------------------------------ |
| Stack     | 定义一系列Services及哪里获取软件包，A Stack可以有不同版本，每个版本可以是活跃/非活跃的，如:Stack = "HDP-1.3.3"。 |
| Service   | 定义Service的组成部分Components（MASTER，SLAVE，CLIENT），如:Service = "HDFS" |
| Extension | 自定义一些列Services添加至一个版本的Stack，A Stack可以有不同版本 |
| Component | 单独的Components遵守某种生命周期（start，stop，install，etc）。如Service = "HDFS"有Components = "NameNode (MASTER)", "Secondary NameNode (MASTER)", "DataNode (SLAVE)" and "HDFS Client (CLIENT)" |

## 1 概览

### 1.1 前提

​	安装Ambari Server后，Stack的定义在/var/lib/ambari-server/resources/stacks上。

### 1.2 结构

​	Stack的定义结构如下：

```
|_ stacks
   |_ <stack_name>
      |_ <stack_version>
         metainfo.xml
         |_ hooks
         |_ repos
            repoinfo.xml
         |_ services
            |_ <service_name>
               metainfo.xml
               metrics.json
               |_ configuration
                  {configuration files}
               |_ package
                  {files, scripts, templates}
```

### 1.3 定义A Service和Components

​	一个service的metainfo.xml文件描述包含的components及其管理脚本，service中的一个component可以是 **MASTER**, **SLAVE** or **CLIENT**，种类告诉Ambari应该使用那种命令来管理和监控组件。

​	对于每一个component，你可以指定特定的命令脚本去执行命令。下面是默认的一系列必须定义的命令。

| 组件种类 | 默认命令                                |
| -------- | --------------------------------------- |
| MASTER   | install, start, stop, configure, status |
| SLAVE    | install, start, stop, configure, status |
| CLIENT   | install, configure, status              |

​	Ambari支持使用python写的不同命令脚本，如YARN Service描述ResourceManager component的 metainfo.xml：

```
<component>
  <name>RESOURCEMANAGER</name>
  <category>MASTER</category>
  <commandScript>
    <script>scripts/resourcemanager.py</script>
    <scriptType>PYTHON</scriptType>
    <timeout>600</timeout>
  </commandScript>
  <customCommands>
    <customCommand>
      <name>DECOMMISSION</name>
      <commandScript>
        <script>scripts/resourcemanager.py</script>
        <scriptType>PYTHON</scriptType>
        <timeout>600</timeout>
      </commandScript>
    </customCommand>
  </customCommands>
</component>
```

​	ResourceManager 是一个Master component，命令脚本在 `services/YARN/package/scripts/resourcemanager.py`，脚本使用python实现默认的生命周期命令，下面是install 方法实现默认的**INSTALL** command：

```
class Resourcemanager(Script):
  def install(self, env):
    self.install_packages(env)
    self.configure(env)
```

​	你可以看到一些自定义的方法，如**decommission** ：

```
def decommission(self, env):
  import params
  ...
  Execute(yarn_refresh_cmd,
          user=yarn_user
  )
  pass
```

### 1.4 运用Stack继承

​	Stacks可以继承其它Stacks来共享命令脚本和配置，这样可以减少代码重复，如下：

- 为子Stack定义repositories

- 在子Stack添加新Services而不是父 Stack

- 重写父Services的命令脚本

- 重写父Services的配置

  例如：**HDP 2.1 Stack**继承**HDP 2.0.6 Stack**，所以**HDP 2.1 Stack**只需要定义需要改变的地方，HDP 2.1 Stack中的 metainfo.xml如下：

  ```
  <metainfo>
    <versions>
      <active>true</active>
    </versions>
    <extends>2.0.6</extends>
  </metainfo>
  ```

### 1.5 实现一个自定义Service

1）HDP 2.0 Stack 自定义service

```
cd /var/lib/ambari-server/resources/stacks/HDP/2.0.6/services
```

2）创建目录**SAMPLESRV**

```
mkdir /var/lib/ambari-server/resources/stacks/HDP/2.0.6/services/SAMPLESRV
cd /var/lib/ambari-server/resources/stacks/HDP/2.0.6/services/SAMPLESRV
```

3）编写metainfo.xml

```
<?xml version="1.0"?>
<metainfo>
    <schemaVersion>2.0</schemaVersion>
    <services>
        <service>
            <name>SAMPLESRV</name>
            <displayName>New Sample Service</displayName>
            <comment>A New Sample Service</comment>
            <version>1.0.0</version>
            <components>
                <component>
                    <name>SAMPLESRV_MASTER</name>
                    <displayName>Sample Srv Master</displayName>
                    <category>MASTER</category>
                    <cardinality>1</cardinality>
                    <commandScript>
                        <script>scripts/master.py</script>
                        <scriptType>PYTHON</scriptType>
                        <timeout>600</timeout>
                    </commandScript>
                </component>
                <component>
                    <name>SAMPLESRV_SLAVE</name>
                    <displayName>Sample Srv Slave</displayName>
                    <category>SLAVE</category>
                    <cardinality>1+</cardinality>
                    <commandScript>
                        <script>scripts/slave.py</script>
                        <scriptType>PYTHON</scriptType>
                        <timeout>600</timeout>
                    </commandScript>
                </component>
                <component>
                    <name>SAMPLESRV_CLIENT</name>
                    <displayName>Sample Srv Client</displayName>
                    <category>CLIENT</category>
                    <cardinality>1+</cardinality>
                    <commandScript>
                        <script>scripts/sample_client.py</script>
                        <scriptType>PYTHON</scriptType>
                        <timeout>600</timeout>
                    </commandScript>
                </component>
            </components>
            <osSpecifics>
                <osSpecific>
                    <osFamily>any</osFamily>  <!-- note: use osType rather than osFamily for Ambari 1.5.0 and 1.5.1 -->
                </osSpecific>
            </osSpecifics>
        </service>
    </services>
</metainfo>
```

4）上面定义服务**SAMPLESRV**，它包含：

- one **MASTER** component "**SAMPLESRV_MASTER**"
- one **SLAVE** component "**SAMPLESRV_SLAVE**"
- one **CLIENT** component "**SAMPLESRV_CLIENT**"

5）创建命令脚本

```
mkdir -p /var/lib/ambari-server/resources/stacks/HDP/2.0.6/services/SAMPLESRV/package/scripts
cd /var/lib/ambari-server/resources/stacks/HDP/2.0.6/services/SAMPLESRV/package/scripts
```

6）脚本内容如下;

​	master.py

```
import sys
from resource_management import *
class Master(Script):
  def install(self, env):
    print 'Install the Sample Srv Master';
  def stop(self, env):
    print 'Stop the Sample Srv Master';
  def start(self, env):
    print 'Start the Sample Srv Master';
     
  def status(self, env):
    print 'Status of the Sample Srv Master';
  def configure(self, env):
    print 'Configure the Sample Srv Master';
if __name__ == "__main__":
  Master().execute()
```

​	 slave.py

```
import sys
from resource_management import *
class Slave(Script):
  def install(self, env):
    print 'Install the Sample Srv Slave';
  def stop(self, env):
    print 'Stop the Sample Srv Slave';
  def start(self, env):
    print 'Start the Sample Srv Slave';
  def status(self, env):
    print 'Status of the Sample Srv Slave';
  def configure(self, env):
    print 'Configure the Sample Srv Slave';
if __name__ == "__main__":
  Slave().execute()
```

sample_client``.py

```
import sys
from resource_management import *
class SampleClient(Script):
  def install(self, env):
    print 'Install the Sample Srv Client';
  def configure(self, env):
    print 'Configure the Sample Srv Client';
if __name__ == "__main__":
  SampleClient().execute()
```

7）重启Ambari Server

```
ambari-server restart
```

## 2 Ambari集成Elasticsearch

​	脚本准备：

```
wget https://github.com/BalaBalaYi/Ambari-Elastic-Service/archive/master.zip
unzip master.zip
mv ELASTICSEARCH-6.4.x ELASTICSEARCH
cp -r ELASTICSEARCH /var/lib/ambari-server/resources/stacks/HDP/3.1/services

sudo ambari-server restart
```

​	