# CenOS7构建YUM本地源

## 1 前言

​	一般开源源码的下载地址在国外，可能被墙或者下载速度过慢，构建本地YUM源有助于加快下载速度，另外对于无法访问外网的内网环境，只能通过构建本地源的方式，本文档记录YUM源构建方法，示例完整记录Ambari的安装YUM源。

## 2 安装HTTP服务

```
sudo yum install httpd
sudo firewall-cmd --add-service=http
sudo firewall-cmd --permanent --add-service=http
sudo systemctl start httpd.service
sudo systemctl enable httpd.service
```

## 3 安装本地源制作相关工具

sudo yum install yum-utils createrepo

## 4 下载安装源

```
1) AMBARI
http://public-repo-1.hortonworks.com/ambari/centos7/2.x/updates/2.7.3.0/ambari.repo
http://public-repo-1.hortonworks.com/ambari/centos7/2.x/updates/2.7.3.0/ambari-2.7.3.0-centos7.tar.gz

2) HDP
http://public-repo-1.hortonworks.com/HDP/centos7/3.x/updates/3.1.0.0/hdp.repo
http://public-repo-1.hortonworks.com/HDP/centos7/3.x/updates/3.1.0.0/HDP-3.1.0.0-centos7-rpm.tar.gz

3) HDP-UTILS
http://public-repo-1.hortonworks.com/HDP-UTILS-1.1.0.22/repos/centos7/HDP-UTILS-1.1.0.22-centos7.tar.gz

4) HDP-GPL
http://public-repo-1.hortonworks.com/HDP-GPL/centos7/3.x/updates/3.1.0.0/hdp.gpl.repo
http://public-repo-1.hortonworks.com/HDP-GPL/centos7/3.x/updates/3.1.0.0/HDP-GPL-3.1.0.0-centos7-gpl.tar.gz
【注：HDP和HDP-UTILS公用一个repo，参见:https://docs.cloudera.com/HDPDocuments/Ambari-2.7.3.0/bk_ambari-installation/content/hdp_31_repositories.html】
```

## 5 制作YUM本地源

```
sudo mkdir /var/www/html/repo

sudo tar -zxvf ambari-2.7.3.0-centos7.tar.gz -C /var/www/html/repo/
sudo tar -zxvf HDP-3.1.0.0-centos7-rpm.tar.gz -C /var/www/html/repo/
sudo tar -zxvf HDP-UTILS-1.1.0.22-centos7.tar.gz -C /var/www/html/repo/
sudo tar -zxvf HDP-GPL-3.1.0.0-centos7-gpl.tar.gz -C /var/www/html/repo/
sudo cp ambari.repo hdp.repo hdp.gpl.repo /etc/yum.repos.d/
```

sudo vim ambari.repo

```
#VERSION_NUMBER=2.7.3.0-139
[ambari-2.7.3.0]
#json.url = http://public-repo-1.hortonworks.com/HDP/hdp_urlinfo.json
name=ambari Version - ambari-2.7.3.0
baseurl=http://172.18.2.29:81/repo/ambari/centos7/2.7.3.0-139
gpgcheck=1
gpgkey=http://172.18.2.29:81/repo/ambari/centos7/2.7.3.0-139/RPM-GPG-KEY/RPM-GPG-KEY-Jenkins
enabled=1
priority=1
```

sudo vim hdp.repo

```
#VERSION_NUMBER=3.1.0.0-78
[HDP-3.1.0.0]
name=HDP Version - HDP-3.1.0.0
baseurl=http://172.18.2.29:81/repo/HDP/centos7/3.1.0.0-78
gpgcheck=1
gpgkey=http://172.18.2.29:81/repo/HDP/centos7/3.1.0.0-78/RPM-GPG-KEY/RPM-GPG-KEY-Jenkins
enabled=1
priority=1

[HDP-UTILS-1.1.0.22]
name=HDP-UTILS Version - HDP-UTILS-1.1.0.22
baseurl=http://172.18.2.29:81/repo/HDP-UTILS/centos7/1.1.0.22
gpgcheck=1
gpgkey=http://172.18.2.29:81/repo/HDP-UTILS/centos7/1.1.0.22/RPM-GPG-KEY/RPM-GPG-KEY-Jenkins
enabled=1
priority=1
```

sudo vim hdp.gpl.repo

```
#VERSION_NUMBER=3.1.0.0-78
[HDP-GPL-3.1.0.0]
name=HDP-GPL Version - HDP-GPL-3.1.0.0
baseurl=http://172.18.2.29:81/repo/HDP-GPL/centos7/3.1.0.0-78
gpgcheck=1
gpgkey=http://172.18.2.29:81/repo/HDP-GPL/centos7/3.1.0.0-78/RPM-GPG-KEY/RPM-GPG-KEY-Jenkins
enabled=1
priority=1
```

## 6 更新YUM源

```
sudo yum clean all
sudo yum list update
sudo yum makecache
sudo yum repolist
```

## 7 测试YUM源

![image-20200811110350544](E:\Typora\Ambari\image-20200811110350544.png)