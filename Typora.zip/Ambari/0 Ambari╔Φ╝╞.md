# Ambari体系结构

## 设计目标

**平台独立性**

系统必须支持不同硬件的操作系统，如RHEL, SLES, Ubuntu, Windows等，平台组件必须可拔插。

**可拔插组件**

架构不能使用特殊的工具和技术，任何特殊的工具技术必须封装至可拔插组件，架构侧重于组件的拔插性和数据的持久化。

**版本管理和升级**

运行在不同节点上的Ambari组件必须支持多版本协议和支持组件独立升级，升级任何组件不会影响集群状态。

**扩展性**

设计应该容易添加新服务、新组件和新的APIs，可扩展性还意味着可以轻松的修改Hadoop技术栈的配置，另外还要考虑支持HDP之外的Hadoop技术栈。

**故障恢复**

对于任何组件的故障，系统都必须使其到达一致性状态，完成故障恢复后操作必须结束挂起，对于某种错误不可恢复时，故障也需要保证一致的状态。

**安全**

实现身份认证和角色授权。

**错误跟踪**

简化故障跟踪的过程，用户可以详细知晓详细信息。

**近实时性操作及反馈**

操作都可以近实时的返回，提供一个进度百分比反馈给用户。

## 专业术语

**Service服务**

Hadoop技术栈里面的服务，如HDFS、HBase、Spark等，一个Service包含多个组件（HDFS包含NameNode, Secondary NameNode, DataNode等）。一个Service也可以仅仅是一个客户端库（如Pig没有 daemon服务，仅仅是一个客户端库）。

**Component组件**

一个服务包含1个或多个组件，例如HDFS包含3个组件：NameNode, Secondary NameNode, DataNode，一个组件可以安装在多个节点。

**Node/Host节点/主机**

Node指的是集群的一台机器，节点和主机在文档中表示同种意思。

**Node-Component节点组件**

Node-component表示某台节点上的组件实例。

**Operation操作**

Operation指的是在集群上执行的一组 changes or actions，如启动一个服务是一个operation。一个operation可以包含多个有序的“actions“。

**Task任务**

Task是发送到节点执行的工作单元。例如在一个节点n1安装上安装datanode，在另外一个节点n2上安装namenode和secondary namenode，n1的task是安装datanode，n2的多个tasks是分别安装namenode和secondary namenode。

**Stage阶段**

一个Stage是在执行一个Operation时包含的一系列Tasks。同一Stage的Tasks可以在不同节点并行运行。

**Action**

本文档Stage和Action对应。

**Stage Plan阶段计划**

一个Operation通常由不同节点上包含依赖关系的一组Tasks组成，这些Tasks可以分为不同阶段，某些阶段的任务需要上一阶段任务完成，同一阶段可以在不同节点并行调度。

**Manifest**

Manifest指发送至节点执行的一组自定义Tasks，Manifest必须完成Tasks的定义和序列化，也可以持久化到磁盘以助恢复或记录。

**Role角色**

对应Component（如NameNode, DataNode），或Action（HDFS rebalancing, HBase smoke test等）。

## 架构体系

**高层架构**

![image-20200710172423996](C:\Users\wangx\AppData\Roaming\Typora\typora-user-images\image-20200710172423996.png)

​	ambari server开放的API分为两类，一类为ambari web提供监控管理服务，另一类用于ambari agent交互，接受ambari agent向ambari server发送的心跳请求。Master模块接受API和Agent interface的请求，完成ambari server的集中式监控管理逻辑，而每个agent节点只负责所在节点的状态采集和维护工作。

**Ambari Server架构**

![image-20200710173141459](C:\Users\wangx\AppData\Roaming\Typora\typora-user-images\image-20200710173141459.png)

​	ambari server内部状态：

1）Live Cluster Status：集群现有状态，各个节点汇报上来的状态信息会更改该状态。

2）Desired Status：用户希望该节点所处状态，是用户在节点上执行的一些列操作，需要更改某些服务的状态，这些状态还没有在节点上产生作用。

3）Action Status：操作状态，是状态改变时的请求状态，可以看做是是一种中间状态，这种状态可以辅助Live Cluster Staus像Desired Status转变。

​	ambari server的Heartbeat Handler模块用于接收各个agent的心跳请求（心跳请求包含两类信息：节点状态信息和返回操作结果），把节点状态信心传递给FSM状态机去维护该节点的状态，并且把返回的节点操作结果信息返回给Action Manager去做进一步处理。

​	Coordinator模块又可以称为API handler，主要接收web端操作请求后，检查是否符合要求，通过Stage Planner分解成一组Actions，然后提供给Action Manager去完成执行操作。

​	另外由上图可见，ambari server 的所有状态信息的维护和变更都会记录在数据库中，用户做的一些更改服务的操作也会记录在数据库中，同时agent可以通过心跳来获取数据库的变更历史。

**Ambari Agent架构**

![image-20200710173233041](C:\Users\wangx\AppData\Roaming\Typora\typora-user-images\image-20200710173233041.png)

​	ambari agent是无状态的，其功能分为两部分：

1）采集所在节点的信息并且汇总发送心跳给ambari server；

2）处理ambari server的执行请求。

因此它有两种队列：

1）消息队列Message Queue（或称ResultQueue）。包括节点状态信息（包括注册信息）和执行结果信息，并且汇总后通过心跳发送给ambari server。

2）操作队列ActionQueue。用于接收ambari server发送过来的状态操作，然后交给执行器调用puppet或python脚本等执行任务。



## 用例

**1. 添加服务：**在已有集群添加新服务，下面的例子是在HDFS的基础上，添加HBase master和slave服务。步骤如下：

- 请求通过API发送到server端，生成一个request-id与请求绑定，然后调用Coordinator（协调器）组件来处理请求。
- 这个API需要实现多个步骤才能最终完成在集群中启动新服务的操作。这个例子中，具体步骤为，按照特定的顺序，在集群中安装先决条件和各个组件，重新配置Nagios服务器来提供监控服务。
- Coordinator组件会查询依赖跟踪器（Dependency Tracker）来找到HBase需要的先决条件。依赖跟踪器会返回HDFS和ZOOKEEPER。Coordinator组件还会查找Nagios服务器的依赖条件，会返回HBase Client。跟踪器同时也会返回所有这些组件和他们需要处于的状态。Coordinator将会把我们期望这些组件所处的状态写到数据库中。
- 在上一步中，参照API语法，Coordinator组件可能还需要客户输入Zookeeper节点信息。
- 然后Coordinator组件会把一个组件列表以及他们的期望状态传给阶段计划（Stage Planner）组件，节点计划组件会返回操作在每个节点执行的阶段及其顺序，包括安装、启动、修改等，阶段计划组件还会调用Manifest生成器来生成每个任务的Manifest。
- Coordinator组件把这些有顺序的阶段说明，连同request-id一起传给了Action Manager组件。
- Action Manager会更新每个组件实例（node-component）的状态，在FSM中，反映为操作正在执行中状态。每个组件实例的改变都会更新FSM。在这个步骤，FSM可能检测到不合法的事件，并抛出失败，这会导致退出操作，所有动作都会被标记为因为同一个错误而失败。
- Action Manager会为每个操作创建一个action-id，并把他加入到计划中。Action Manager首先挑选计划中的第一个阶段，并把所有任务向受影响的节点发出。当第一个阶段完成后，第二个节点就会被执行。Action Manager也会开启一个定时动作。
- 心跳句柄（heartbeat handler）会返回动作的响应，并通知Action Manager。然后Action Manager向FSM发出一个事件来更新状态。如果发生超时，动作将会再次被调度执行，或者被标记为失败。一旦一个动作所涉及的所有节点都返回了完成信息，这个动作就被认为已经完成了。当一个阶段的所有动作都完成了，这个节点也就被认为是完成了。（这个描述跟之前“术语”中描述的动作（Action）和阶段（Stage）的描述不一致）
- 动作完成也会被记录在数据库中。
- Action Manager会执行下一个阶段并重复这个过程。

**2.执行冒烟测试：**集群已经安装完成HDFS和HBase，用户想之心冒烟测试。

- 跟上面一样，server通过api接收到了请求，并生成一个request-id，由Coordinator组件的handler来处理这个请求。
- handler调用dependency tracker来确认HBase服务已经被安装，并且正在运行着。如果HBase没有在运行，dependency trakcer会抛出一个错误。handler还会决定冒烟测试在哪里进行。dependency traker会暴露一个方法来告诉Coordinator哪个HBase客户端会用来执行测试。Stage Planner被调用来生成一个计划来执行测试。在这个用例中，计划只有涉及到一个组件实例的一个阶段。
- 剩下的步骤跟前一个例子相似。在这个例子中，FSM将hbase-smoketest作为一个角色看待。

**3.重启配置服务**

- 集群已经启动，并且服务和依赖也都已经安装并启动。
- 服务器接收到了一个保存配置的请求，一个新的配置快照被保存在了服务器。请求可能也包含了配置更新会影响哪些服务或者角色、节点。这意味着持久层要针对服务、组件、节点记录配置的修改，配置的最后的版本是什么，以及在请求中影响了哪些对象。
- 用户可以通过多次调用这个操作，来设置配置的多个checkpoint。
- 有时候，用户希望将新配置部署到集群中。在这个场景，用户发出一个请求，来将新配置部署到指定的服务、组件、组件实例上。
- 可以根据API的不同，指定配置的版本，或使用最新版本的配置。
- Coordinator将会用两步来完成“重新配置”操作。首先，会生成一个阶段来停止请求中的服务，然后会生成一个阶段来开启服务。Coordinator将会通过Action Manager来先后执行这两个计划，剩下的步骤就跟前面描述的一样了。

**4.ambari master故障重启**

- 假设ambari master宕机了，有多个场景需要被讨论。
- 假设：
  - 期望状态已经被保留至数据库。
  - 所有待执行的操作都被保存到了数据库。
  - 现有状态已经被记录至数据库，然而agent不能发送回来那些需要被存储在数据库中的当前状态。
  - 所有状态都是幕等的。
- 需要采取的Actions
  - Ambari Master
    - action layer需要重排待提交或者已经排列（但未执行完成）的stages，通过Heartbeat Handler返回给agents并且允许重新执行这些步骤。
    - 在ambari server未完全恢复前，ambari server不再接受任何新的请求。
    - 如果在live state和desired state（如live state是STARTED or STARTING但是desired state是STOPPED），必须要有个触发器来生成阶段计划，来把当前状态变成期望状态。但是如果期望状态是STOPPED，当前状态是STOP_FAILED，这样可能通过接口已经不能完成停止操作，这样就需要管理员来人工完成停止工作。
  - Ambari Agent
    - 当master消失的时候，agent不应该死亡。它应该继续定期轮询，并在master恢复时按需恢复。
    - ambari agent必须保存所有计划发送给master的有用信息，以确保即使连接失败了，也可以在master恢复时重新发送信息。
    - agent之前正在注册的时，master死掉了，它可能需要重新注册。



**5.下架一个Datanodes子集**

- Decommissioning操作将在puppet层，作为一个动作，使用hadoop-admin角色来执行。这个角色需要安装hadoop-client和admin权限。
- Decommission操作的manifest将由带有特定参数hadoop-admin角色组成，例如参数可以是一个datanodes的列表，具有特定标识的动作等。
- Coordinator将标识一个节点，用来执行hadoop-admin操作。这个节点必须是可用的。
- 下架操作将跟谁执行操作的节点角色的状态机，如果下架操作已经在namenode上被执行了，就应该认为是成功了。例如在管理命令成功发送到datanode的时候。
- 节点是否被下架，应该可以在另外一个进程中被查询到。这个信息在namenode UI中是可用的。ambari应该提供另外的api来查询正在下架或已经下架的节点、
- ambari没有记录一个datanode是否正在被下架，或者已经被下架了。为了在ambari中处理已经被下架的datanode节点，应该提供另外的api来让ambari停止或卸载那些datanode。

## Agent

​	agent每隔几秒就会向master发一次心跳包，并且通过心跳包的回应接收命令。心跳回应是master发送命令给agent的唯一途径。发送的命令将被放入一个**action queue**， 将被action执行器取出执行。**Action executioner**

（action执行器）将根据依据命令的类型和action的类型选取正确的工具（Puppet、Python等）来执行。心跳回应的命令会在agent端异步执行。动作执行器会把执行返回信息或进度信息放入**message queue**，agent会在下一次心跳包中把所有的消息发往master。

## Recovery

master的故障恢复有两种选择。

- **Recovery based on actions：**这种情形中，每一个action都被持久化，重启时master检查挂起的actions然后重新调度它们。集群状态也被持久化至数据库，master重启时会rebuild状态机。但是有一一种罕见的情形，某些actions执行完成了，但是在记录它们完成前master崩溃了，这时需要有一种机制来确认这个操作时幂等的，并且将数据库中所有被标记为完成或失败的动作都重新制定计划并执行。被持久化的动作可以通过redo logs查看。
- **基于期望状态恢复：**在这种情形下，master持久化了一个期望状态，并且通过重启的手段来使集群达到这个状态。

基于操作的恢复方法与我们总体设计更贴切，因为我们预先计划了一个操作并持久化它，即使我们持久化的是期望转态，恢复操作也需要重新计划actions。而且通过ambari的视角，基于期望状态恢复的方法不能捕捉到集群的某些不改变集群状态的操作，比如smoke测试或hdfs平衡。持久化动作通过edo logs查看。

Agent的恢复仅仅需要重启agent，因为agent是无状态的。master通过心跳丢失超越一定阀值来探测agent的失败。

