# Ambari编译打包

## 1 环境准备

```
1）依赖项安装
yum install -y git svn node python-devel rpm-build gcc-c++
2）安装maven, JDK8
3）下载 python2.7 设置工具
sudo wget https://files.pythonhosted.org/packages/25/5d/cc55d39ac39383dd6e04ae80501b9af3cc455be64740ad68a4e12ec81b00/setuptools-0.6c11-py2.7.egg#md5=fe1f997bc722265116870bc7919059ea
sudo sh setuptools-0.6c11-py2.7.egg
```

## 2 源码编译

```
1）源码准备
wget https://archive.apache.org/dist/ambari/ambari-2.7.3/apache-ambari-2.7.3-src.tar.gz
tar xfvz apache-ambari-2.7.3-src.tar.gz && cd ambari-2.7.3
2）源码编译
mvn -B install package rpm:rpm -DnewVersion=2.7.3.0.0 -DskipTests -Drat.skip -Dpython.ver="python >= 2.6"
3）夜间无间断编译
mvn -B --fail-at-end install package rpm:rpm -DnewVersion=2.7.3.0.0 -DskipTests -Drat.skip -Dpython.ver="python >= 2.6"
```

## 3 异常解决

```
异常1：
[ERROR] Failed to execute goal org.codehaus.mojo:exec-maven-plugin:3.0.0:exec (Bower install) on project ambari-admin: Command execution failed. Process exited with an error: 1 (Exit value: 1) -> [Help 1]
解决：
进入ambari-admin项目的pom.xml,修改nodeVersion和npmVersion为已安装版本
nodeVersion	v4.5.0	-->	v9.3.0
npmVersion	2.15.0	-->	5.5.1
mvn clean install -Drat.skip=true

异常2：
[ERROR] Failed to execute goal on project ambari-metrics-hadoop-sink: Could not resolve dependencies for project org.apache.ambari:ambari-metrics-hadoop-sink:jar:2.6.2.0.0: Could not find artifact org.apache.hadoop:hadoop-common:jar:2.7.3.2.6.4.0-91 in apache-hadoop (http://repo.hortonworks.com/content/groups/public/) -> [Help 1]
解决：
由于ambari-metrics-hadoop-sink的pom.xml文件中hadoop版本2.7.3.2.6.4.0-91地址已经失效，更改版本为2.7.3.2.6.4.1-30，重新编译即可

异常3：
[ERROR] Failed to execute goal com.github.eirslett:frontend-maven-plugin:1.4:install-node-and-yarn (install node and yarn) on project ambari-web: Could not extract the Yarn archive: Could not extract archive: '/opt/bigdata-cluster/softwares/apache-maven-3.3.9/m2/repo/com/github/eirslett/yarn/0.23.2/yarn-0.23.2./yarn-v0.23.2.tar.gz': EOFException -> [Help 1]
解决：yarn-v0.23.2.tar.gz所在网站无法下载，包损坏，去下载完整包，替换损坏包

异常4：
[INFO] Ambari Metrics Collector ........................... FAILURE [  0.141 s]
[INFO] Ambari Metrics Monitor ............................. SKIPPED
[INFO] Ambari Metrics Grafana ............................. SKIPPED
[INFO] Ambari Metrics Assembly ............................ SKIPPED
[INFO] Ambari Server ...................................... SKIPPED
[INFO] Ambari Functional Tests ............................ SKIPPED
[INFO] Ambari Agent ....................................... SKIPPED
[INFO] ambari-logsearch ................................... SKIPPED
[INFO] Ambari Logsearch Appender .......................... SKIPPED
[INFO] Ambari Logsearch Portal ............................ SKIPPED
[INFO] Ambari Logsearch Log Feeder ........................ SKIPPED
[INFO] Ambari Logsearch Solr Client ....................... SKIPPED
[INFO] Ambari Infra Solr Plugin ........................... SKIPPED
[INFO] Ambari Logsearch Assembly .......................... SKIPPED
[INFO] Ambari Logsearch Integration Test .................. SKIPPED
[INFO] ------------------------------------------------------------------------
[INFO] BUILD FAILURE
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 03:21 min
[INFO] Finished at: 2020-08-12T11:19:12+08:00
[INFO] Final Memory: 123M/3150M
[INFO] ------------------------------------------------------------------------
[ERROR] Failed to execute goal on project ambari-metrics-timelineservice: Could not resolve dependencies for project org.apache.ambari:ambari-metrics-timelineservice:jar:2.6.2.0.0: The following artifacts could not be resolved: org.apache.phoenix:phoenix-core:jar:4.7.0.2.6.4.0-91, org.apache.hadoop:hadoop-common:jar:2.7.3.2.6.4.0-91, org.apache.hadoop:hadoop-annotations:jar:2.7.3.2.6.4.0-91, org.apache.hadoop:hadoop-common:jar:tests:2.7.3.2.6.4.0-91, org.apache.hadoop:hadoop-yarn-common:jar:tests:2.7.3.2.6.4.0-91, org.apache.hadoop:hadoop-yarn-common:jar:2.7.3.2.6.4.0-91, org.apache.hadoop:hadoop-yarn-api:jar:2.7.3.2.6.4.0-91, org.apache.hadoop:hadoop-yarn-server-common:jar:2.7.3.2.6.4.0-91, org.apache.phoenix:phoenix-core:jar:tests:4.7.0.2.6.4.0-91, org.apache.hbase:hbase-it:jar:tests:1.1.2.2.6.4.0-91, org.apache.hbase:hbase-testing-util:jar:1.1.2.2.6.4.0-91: Failure to find org.apache.phoenix:phoenix-core:jar:4.7.0.2.6.4.0-91 in http://repo.hortonworks.com/content/groups/public/ was cached in the local repository, resolution will not be reattempted until the update interval of apache-hadoop has elapsed or updates are forced -> [Help 1]
解决：
修改ambari-metrics-timelineservice项目pom.xml文件，修改hadoop.version为2.7.3.2.6.4.1-30
重新编译解决。

异常5：
[INFO] Ambari Main ........................................ SUCCESS [  1.126 s]
[INFO] Apache Ambari Project POM .......................... SUCCESS [  0.217 s]
[INFO] Ambari Web ......................................... SUCCESS [ 31.035 s]
[INFO] Ambari Views ....................................... SUCCESS [  1.124 s]
[INFO] Ambari Admin View .................................. SUCCESS [ 11.134 s]
[INFO] utility ............................................ SUCCESS [  0.111 s]
[INFO] ambari-metrics ..................................... SUCCESS [  0.434 s]
[INFO] Ambari Metrics Common .............................. SUCCESS [  4.251 s]
[INFO] Ambari Metrics Hadoop Sink ......................... SUCCESS [  2.578 s]
[INFO] Ambari Metrics Flume Sink .......................... SUCCESS [  1.649 s]
[INFO] Ambari Metrics Kafka Sink .......................... SUCCESS [  1.893 s]
[INFO] Ambari Metrics Storm Sink .......................... SUCCESS [  2.415 s]
[INFO] Ambari Metrics Storm Sink (Legacy) ................. SUCCESS [  2.297 s]
[INFO] Ambari Metrics Collector ........................... FAILURE [03:52 min]
[INFO] Ambari Metrics Monitor ............................. SKIPPED
[INFO] Ambari Metrics Grafana ............................. SKIPPED
[INFO] Ambari Metrics Assembly ............................ SKIPPED
[INFO] Ambari Server ...................................... SKIPPED
[INFO] Ambari Functional Tests ............................ SKIPPED
[INFO] Ambari Agent ....................................... SKIPPED
[INFO] ambari-logsearch ................................... SKIPPED
[INFO] Ambari Logsearch Appender .......................... SKIPPED
[INFO] Ambari Logsearch Portal ............................ SKIPPED
[INFO] Ambari Logsearch Log Feeder ........................ SKIPPED
[INFO] Ambari Logsearch Solr Client ....................... SKIPPED
[INFO] Ambari Infra Solr Plugin ........................... SKIPPED
[INFO] Ambari Logsearch Assembly .......................... SKIPPED
[INFO] Ambari Logsearch Integration Test .................. SKIPPED
[INFO] ------------------------------------------------------------------------
[INFO] BUILD FAILURE
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 04:52 min
[INFO] Finished at: 2020-08-12T11:29:21+08:00
[INFO] Final Memory: 118M/4077M
[INFO] ------------------------------------------------------------------------
[ERROR] Failed to execute goal on project ambari-metrics-timelineservice: Could not resolve dependencies for project org.apache.ambari:ambari-metrics-timelineservice:jar:2.6.2.0.0: The following artifacts could not be resolved: org.apache.phoenix:phoenix-core:jar:4.7.0.2.6.4.0-91, org.apache.phoenix:phoenix-core:jar:tests:4.7.0.2.6.4.0-91, org.apache.hbase:hbase-it:jar:tests:1.1.2.2.6.4.0-91, org.apache.hbase:hbase-testing-util:jar:1.1.2.2.6.4.0-91: Failure to find org.apache.phoenix:phoenix-core:jar:4.7.0.2.6.4.0-91 in http://repo.hortonworks.com/content/groups/public/ was cached in the local repository, resolution will not be reattempted until the update interval of apache-hadoop has elapsed or updates are forced -> [Help 1]
解决：
修改ambari-metrics-timelineservice项目pom.xml文件
phoenix.version	4.7.0.2.6.4.0-91 -> 4.7.0.2.6.4.100-1
hbase.version	1.1.2.2.6.4.0-91 -> 1.1.2.2.6.4.15-1

异常6：
[INFO] Reactor Summary:
[INFO] 
[INFO] Ambari Main ........................................ SUCCESS [ 10.980 s]
[INFO] Apache Ambari Project POM .......................... SUCCESS [  0.555 s]
[INFO] Ambari Web ......................................... SUCCESS [01:22 min]
[INFO] Ambari Views ....................................... SUCCESS [  5.385 s]
[INFO] Ambari Admin View .................................. SUCCESS [01:11 min]
[INFO] utility ............................................ SUCCESS [  1.531 s]
[INFO] ambari-metrics ..................................... SUCCESS [  2.702 s]
[INFO] Ambari Metrics Common .............................. SUCCESS [  9.518 s]
[INFO] Ambari Metrics Hadoop Sink ......................... SUCCESS [  9.419 s]
[INFO] Ambari Metrics Flume Sink .......................... SUCCESS [  3.122 s]
[INFO] Ambari Metrics Kafka Sink .......................... SUCCESS [  6.483 s]
[INFO] Ambari Metrics Storm Sink .......................... SUCCESS [  4.527 s]
[INFO] Ambari Metrics Storm Sink (Legacy) ................. SUCCESS [  5.563 s]
[INFO] Ambari Metrics Collector ........................... FAILURE [ 11.466 s]
[INFO] Ambari Metrics Monitor ............................. SUCCESS [  3.284 s]
[INFO] Ambari Metrics Grafana ............................. FAILURE [  1.649 s]
[INFO] Ambari Metrics Assembly ............................ SKIPPED
[INFO] Ambari Server ...................................... FAILURE [05:39 min]
[INFO] Ambari Functional Tests ............................ SKIPPED
[INFO] Ambari Agent ....................................... SUCCESS [03:30 min]
[INFO] ambari-logsearch ................................... SUCCESS [  2.962 s]
[INFO] Ambari Logsearch Appender .......................... SUCCESS [  0.863 s]
[INFO] Ambari Logsearch Portal ............................ FAILURE [ 12.860 s]
[INFO] Ambari Logsearch Log Feeder ........................ FAILURE [ 13.776 s]
[INFO] Ambari Logsearch Solr Client ....................... SUCCESS [  6.872 s]
[INFO] Ambari Infra Solr Plugin ........................... SUCCESS [  5.301 s]
[INFO] Ambari Logsearch Assembly .......................... SKIPPED
[INFO] Ambari Logsearch Integration Test .................. SUCCESS [  7.087 s]
[INFO] ------------------------------------------------------------------------
[INFO] BUILD FAILURE
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 13:54 min
[INFO] Finished at: 2020-08-12T13:47:47+08:00
[INFO] Final Memory: 221M/3291M
[INFO] ------------------------------------------------------------------------
[ERROR] Failed to execute goal org.apache.maven.plugins:maven-antrun-plugin:1.7:run (default) on project ambari-metrics-timelineservice: An Ant BuildException has occured: Error while expanding /opt/bigdata-cluster/softwares/ambari-2.7.3/ambari-metrics/ambari-metrics-timelineservice/target/embedded/hbase.tar.gz
[ERROR] java.io.EOFException: Unexpected end of ZLIB input stream
[ERROR] around Ant part ...<untar src="/opt/bigdata-cluster/softwares/ambari-2.7.3/ambari-metrics/ambari-metrics-timelineservice/target/embedded/hbase.tar.gz" dest="/opt/bigdata-cluster/softwares/ambari-2.7.3/ambari-metrics/ambari-metrics-timelineservice/target/embedded" compression="gzip"/>... @ 6:268 in /opt/bigdata-cluster/softwares/ambari-2.7.3/ambari-metrics/ambari-metrics-timelineservice/target/antrun/build-Download HBase.xml
[ERROR] -> [Help 1]
[ERROR] Failed to execute goal org.apache.maven.plugins:maven-antrun-plugin:1.7:run (default) on project ambari-metrics-grafana: An Ant BuildException has occured: Error while expanding /opt/bigdata-cluster/softwares/ambari-2.7.3/ambari-metrics/ambari-metrics-grafana/target/grafana/grafana.tgz
[ERROR] java.io.EOFException: Unexpected end of ZLIB input stream
[ERROR] around Ant part ...<untar src="/opt/bigdata-cluster/softwares/ambari-2.7.3/ambari-metrics/ambari-metrics-grafana/target/grafana/grafana.tgz" dest="/opt/bigdata-cluster/softwares/ambari-2.7.3/ambari-metrics/ambari-metrics-grafana/target/grafana" compression="gzip"/>... @ 6:249 in /opt/bigdata-cluster/softwares/ambari-2.7.3/ambari-metrics/ambari-metrics-grafana/target/antrun/build-Download Ambari Grafana.xml
[ERROR] -> [Help 1]
[ERROR] Failed to execute goal org.codehaus.mojo:xml-maven-plugin:1.0:transform (default) on project ambari-server: Failed to transform input file /opt/bigdata-cluster/softwares/ambari-2.7.3/ambari-server/target/findbugs/findbugsXml.html: The entity name must immediately follow the '&' in the entity reference. -> [Help 1]
[ERROR] Failed to execute goal on project ambari-logsearch-portal: Could not resolve dependencies for project org.apache.ambari:ambari-logsearch-portal:jar:2.6.2.0.0: Failed to collect dependencies at org.apache.hadoop:hadoop-common:jar:2.7.3.2.6.4.0-91: Failed to read artifact descriptor for org.apache.hadoop:hadoop-common:jar:2.7.3.2.6.4.0-91: Could not transfer artifact org.apache.hadoop:hadoop-common:pom:2.7.3.2.6.4.0-91 from/to spring-milestones (http://repo.spring.io/milestone): Access denied to: http://repo.spring.io/milestone/org/apache/hadoop/hadoop-common/2.7.3.2.6.4.0-91/hadoop-common-2.7.3.2.6.4.0-91.pom , ReasonPhrase:Forbidden. -> [Help 2]
[ERROR] Failed to execute goal on project ambari-logsearch-logfeeder: Could not resolve dependencies for project org.apache.ambari:ambari-logsearch-logfeeder:jar:2.6.2.0.0: Failed to collect dependencies at org.apache.hadoop:hadoop-hdfs:jar:2.7.3.2.6.4.0-91: Failed to read artifact descriptor for org.apache.hadoop:hadoop-hdfs:jar:2.7.3.2.6.4.0-91: Could not transfer artifact org.apache.hadoop:hadoop-hdfs:pom:2.7.3.2.6.4.0-91 from/to spring-milestones (http://repo.spring.io/milestone): Access denied to: http://repo.spring.io/milestone/org/apache/hadoop/hadoop-hdfs/2.7.3.2.6.4.0-91/hadoop-hdfs-2.7.3.2.6.4.0-91.pom , ReasonPhrase:Forbidden. -> [Help 2]
[ERROR] 
[ERROR] To see the full stack trace of the errors, re-run Maven with the -e switch.
[ERROR] Re-run Maven using the -X switch to enable full debug logging.
[ERROR] 
[ERROR] For more information about the errors and possible solutions, please read the following articles:
[ERROR] [Help 1] http://cwiki.apache.org/confluence/display/MAVEN/MojoExecutionException
[ERROR] [Help 2] http://cwiki.apache.org/confluence/display/MAVEN/DependencyResolutionException
[ERROR] 
[ERROR] After correcting the problems, you can resume the build with the command
[ERROR]   mvn <goals> -rf :ambari-metrics-timelineservice
解决：
修改ambari-logsearch项目中pom.xml文件，修改hadoop.version为2.7.3.2.6.4.1-30
修改ambari-metrics项目pom.xml文件
 <hbase.tar>http://172.18.2.29:81/repository/defined/hbase-1.1.2.2.6.4.0-91.tar.gz</hbase.tar>
 <hadoop.tar>http://172.18.2.29:81/repository/defined/hadoop-2.7.3.2.6.4.0-91.tar.gz</hadoop.tar>
 <phoenix.tar>http://172.18.2.29:81/repository/defined/phoenix-4.7.0.2.6.4.0-91.tar.gz</phoenix.tar>

 异常7：
[INFO] BUILD FAILURE
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 01:06 min
[INFO] Finished at: 2020-08-13T11:42:38+08:00
[INFO] Final Memory: 55M/2560M
[INFO] ------------------------------------------------------------------------
[ERROR] Failed to execute goal org.apache.rat:apache-rat-plugin:0.12:check (default) on project ambari-admin: Too many files with unapproved license: 1 See RAT report in: /opt/bigdata-cluster/softwares/apache-ambari-2.7.3-src/ambari-admin/target/rat.txt -> [Help 1]
解决：增加-Drat.skip=true
mvn -B clean install jdeb:jdeb -DnewVersion=2.7.3.0.0 -DbuildNumber=4295bb16c439cbc8fb0e7362f19768dde1477868 -DskipTests -Dpython.ver="python >= 2.6" -Drat.skip=true

异常8：
ambari-metrics项目编译下载速度超级慢，通过ping nexus-private.hortonworks.com，发现不通，修改ambari-metrics项目pom文件，修改为http://repo.hortonworks.com/content/groups/public
进入ambari-metrics项目单独编译，mvn install package -Dbuild-rpm -DskipTests

异常9：
Download HBase:
    [mkdir] Created dir: /opt/bigdata-cluster/softwares/apache-ambari-2.7.3-src/ambari-metrics/ambari-metrics-timelineservice/target/embedded
      [get] Getting: http://dev.hortonworks.com.s3.amazonaws.com/HDP/centos7/3.x/BUILDS/3.0.0.0-1634/tars/hbase/hbase-2.0.0.3.0.0.0-1634-bin.tar.gz
      [get] To: /opt/bigdata-cluster/softwares/apache-ambari-2.7.3-src/ambari-metrics/ambari-metrics-timelineservice/target/embedded/hbase.tar.gz
      [get] Error opening connection java.io.IOException: Server returned HTTP response code: 403 for URL: http://dev.hortonworks.com.s3.amazonaws.com/HDP/centos7/3.x/BUILDS/3.0.0.0-1634/tars/hbase/hbase-2.0.0.3.0.0.0-1634-bin.tar.gz
      [get] Error opening connection java.io.IOException: Server returned HTTP response code: 403 for URL: http://dev.hortonworks.com.s3.amazonaws.com/HDP/centos7/3.x/BUILDS/3.0.0.0-1634/tars/hbase/hbase-2.0.0.3.0.0.0-1634-bin.tar.gz
      [get] Error opening connection java.io.IOException: Server returned HTTP response code: 403 for URL: http://dev.hortonworks.com.s3.amazonaws.com/HDP/centos7/3.x/BUILDS/3.0.0.0-1634/tars/hbase/hbase-2.0.0.3.0.0.0-1634-bin.tar.gz
      [get] Can't get http://dev.hortonworks.com.s3.amazonaws.com/HDP/centos7/3.x/BUILDS/3.0.0.0-1634/tars/hbase/hbase-2.0.0.3.0.0.0-1634-bin.tar.gz to /opt/bigdata-cluster/softwares/apache-ambari-2.7.3-src/ambari-metrics/ambari-metrics-timelineservice/target/embedded/hbase.tar.gz
[INFO] ------------------------------------------------------------------------
解决：

异常9：
    [mkdir] Created dir: /opt/bigdata-cluster/softwares/apache-ambari-2.7.3-src/ambari-infra/ambari-infra-solr-client/target/migrate/data
      [get] Getting: http://central.maven.org/maven2/org/apache/lucene/lucene-core/6.6.2/lucene-core-6.6.2.jar
      [get] To: /opt/bigdata-cluster/softwares/apache-ambari-2.7.3-src/ambari-infra/ambari-infra-solr-client/target/migrate/lucene-core-6.6.2.jar
      [get] Error getting http://central.maven.org/maven2/org/apache/lucene/lucene-core/6.6.2/lucene-core-6.6.2.jar to /opt/bigdata-cluster/softwares/apache-ambari-2.7.3-src/ambari-infra/ambari-infra-solr-client/target/migrate/lucene-core-6.6.2.jar
解决：
ambari-infra-solr-client和ambari-infra-assembly中pom文件
将http://central.maven.org/maven2修改为https://repo.hortonworks.com/content/groups/public
mvn package -Dbuild-rpm -DskipTests

mvn -B package rpm:rpm -DnewVersion=2.7.3.0.0 -DskipTests -Dpython.ver="python >= 2.6" -Drat.skip=true -Preplaceurl
[INFO] Reactor Summary:
[INFO] 
[INFO] Ambari Main ........................................ SUCCESS [ 11.899 s]
[INFO] Apache Ambari Project POM .......................... SUCCESS [  0.374 s]
[INFO] Ambari Web ......................................... SUCCESS [03:10 min]
[INFO] Ambari Views ....................................... SUCCESS [ 15.609 s]
[INFO] Ambari Admin View .................................. SUCCESS [01:24 min]
[INFO] ambari-utility ..................................... SUCCESS [ 19.438 s]
[INFO] ambari-metrics ..................................... SUCCESS [  0.648 s]
[INFO] Ambari Metrics Common .............................. SUCCESS [ 18.264 s]
[INFO] Ambari Metrics Hadoop Sink ......................... SUCCESS [ 23.164 s]
[INFO] Ambari Metrics Flume Sink .......................... SUCCESS [  5.518 s]
[INFO] Ambari Metrics Kafka Sink .......................... SUCCESS [  7.162 s]
[INFO] Ambari Metrics Storm Sink .......................... SUCCESS [  8.714 s]
[INFO] Ambari Metrics Storm Sink (Legacy) ................. SUCCESS [ 12.217 s]
[INFO] Ambari Metrics Collector ........................... SUCCESS [05:58 min]
[INFO] Ambari Metrics Monitor ............................. SUCCESS [ 14.913 s]
[INFO] Ambari Metrics Grafana ............................. SUCCESS [  4.220 s]
[INFO] Ambari Metrics Host Aggregator ..................... SUCCESS [ 39.130 s]
[INFO] Ambari Metrics Assembly ............................ SUCCESS [06:15 min]
[INFO] Ambari Service Advisor ............................. SUCCESS [  5.797 s]
[INFO] Ambari Server ...................................... SUCCESS [09:50 min]
[INFO] Ambari Functional Tests ............................ SUCCESS [  8.095 s]
[INFO] Ambari Agent ....................................... SUCCESS [02:16 min]
[INFO] ambari-logsearch ................................... SUCCESS [  0.426 s]
[INFO] Ambari Logsearch Appender .......................... SUCCESS [  1.056 s]
[INFO] Ambari Logsearch Config Api ........................ SUCCESS [  1.704 s]
[INFO] Ambari Logsearch Config JSON ....................... SUCCESS [  4.666 s]
[INFO] Ambari Logsearch Config Solr ....................... SUCCESS [  1.530 s]
[INFO] Ambari Logsearch Config Zookeeper .................. SUCCESS [  2.390 s]
[INFO] Ambari Logsearch Config Local ...................... SUCCESS [  0.547 s]
[INFO] Ambari Logsearch Log Feeder Plugin Api ............. SUCCESS [  0.990 s]
[INFO] Ambari Logsearch Log Feeder Container Registry ..... SUCCESS [  3.569 s]
[INFO] Ambari Logsearch Log Feeder ........................ SUCCESS [ 12.650 s]
[INFO] Ambari Logsearch Web ............................... SUCCESS [09:09 min]
[INFO] Ambari Logsearch Server ............................ SUCCESS [ 31.912 s]
[INFO] Ambari Logsearch Assembly .......................... SUCCESS [  1.040 s]
[INFO] Ambari Logsearch Integration Test .................. SUCCESS [ 15.444 s]
[INFO] ambari-infra ....................................... SUCCESS [  1.118 s]
[INFO] Ambari Infra Solr Client ........................... SUCCESS [44:39 min]
[INFO] Ambari Infra Solr Plugin ........................... SUCCESS [ 18.961 s]
[INFO] Ambari Infra Manager ............................... SUCCESS [ 28.074 s]
[INFO] Ambari Infra Assembly .............................. SUCCESS [  0.628 s]
[INFO] Ambari Infra Manager Integration Tests ............. SUCCESS [  3.059 s]
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 01:28 h
[INFO] Finished at: 2020-08-19T13:11:26+08:00
[INFO] Final Memory: 622M/10189M
[INFO] ------------------------------------------------------------------------
```

## 4 自定义ES版Ambari

### 4.1 定义组件服务

```
编写组件服务模块，参见【3 Ambari自定义组件】
将编写好的python模块放入目录，有两种方式：
ambari-server/src/main/resources/stacks/HDP/2.6		放入对应版本，只在对应版本生效
ambari-server/src/main/resources/common-services	放入公共服务，在所有版本都生效
自定义组件，建议放入公共服务板块，后续升级也会存在。
```

### 4.2 编译打包

```
1）重新编译打包：
mvn -B package rpm:rpm -DnewVersion=2.7.3.0.0 -DbuildNumber=4295bb16c439cbc8fb0e7362f19768dde1477868 -DskipTests -Dpython.ver="python >= 2.6" -Drat.skip=true -Preplaceurl
成功后将生成target/rpm/ambari/RPMS/noarch/ambari-2.7.3.0-0.noarch.rpm
2）将生成rpm包拷贝至自定义YUM源
sudo cp ambari-server-2.7.3.0-0.x86_64.rpm ambari-agent-2.7.3.0-0.x86_64.rpm /var/www/html/repository/RPMS
```

### 4.3 部署Ambari

```
安装server
sudo yum install http://172.18.2.29:81/repository/RPMS/ambari-server-2.7.3.0-0.x86_64.rpm
安装agent
sudo yum install http://172.18.2.29:81/repository/RPMS/ambari-agent-2.7.3.0-0.x86_64.rpm
查看ambari-server ambari-agent命令是否成功安装，后续步骤参见【2 Ambari安装部署】
查看自定义的组件是否已经部署，查看ES是否已经被部署，如下已经被成功部署：
```

![image-20200820110547422](E:\Typora\Ambari\image-20200820110547422.png)

```
异常1;
/usr/sbin/ambari-server: line 34: buildNumber: unbound variable
解决方案1：
编辑/usr/sbin/ambari-server 增加buildNumber=2.7.3.0.0即可
解决方案2：
在编译ambari的时候加上-DbuildNumber=4295bb16c439cbc8fb0e7362f19768dde1477868
```

