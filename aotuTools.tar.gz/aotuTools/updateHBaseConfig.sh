#!/bin/bash

for i in `cat /opt/hadoop/softwares/roles/hosts`
do
 hostname=$i
 ssh -t $hostname "cd /opt/hadoop/bigdata-cluster/modules/hbase-1.4.8/conf;ln -s /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/core-site.xml core-site.xml;ln -s /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/hdfs-site.xml hdfs-site.xml"
done

