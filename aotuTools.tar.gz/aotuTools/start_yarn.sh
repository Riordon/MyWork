#!/bin/bash

cd /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1

# rm
> /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
for i in `cat /opt/hadoop/softwares/roles/hadoop/nns`
do
 echo $i >>/opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
done
sbin/yarn-daemons.sh start resourcemanager

# 
> /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
for i in `cat /opt/hadoop/softwares/roles/hadoop/dns`
do
 echo $i >>/opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
done
sbin/yarn-daemons.sh start nodemanager
