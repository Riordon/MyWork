#!/bin/bash

# WARN
exit 

cd /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1
bin/hdfs zkfc -formatZK
sleep 10s

echo "zcloudgpsapp07" > /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
echo "zcloudgpsapp06" >> /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
sbin/hadoop-daemons.sh start zkfc
sleep 5s

echo "zcloudgpsapp05" >> /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
sbin/hadoop-daemons.sh start journalnode
sleep 5s

bin/hdfs namenode -format
sleep 10s
sbin/hadoop-daemon.sh start namenode
sleep 5s

ssh -t zcloudgpsapp06 "cd /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1;sbin/hadoop-daemon.sh start namenode;sleep 5s; bin/hdfs namenode -bootstrapStandby;sleep 5s;sbin/hadoop-daemon.sh start namenode"

echo "zcloudgpsapp04" > /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
echo "zcloudgpsapp03" >> /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
echo "zcloudgpsapp02" >> /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
echo "zcloudgpsapp01" >> /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves

sbin/hadoop-daemons.sh start datanode
