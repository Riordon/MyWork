#!/bin/bash

cd /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1
# zkfc/nns
> /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
for i in `cat /opt/hadoop/softwares/roles/hadoop/nns`
do
 echo $i
 echo $i >>/opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
done
sbin/hadoop-daemons.sh start zkfc
sbin/hadoop-daemons.sh start namenode
sleep 5s

# jns
> /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
for i in `cat /opt/hadoop/softwares/roles/hadoop/jns`
do
 echo $i
 echo $i >>/opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
done
sbin/hadoop-daemons.sh start journalnode
sleep 5s

# dns
> /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
for i in `cat /opt/hadoop/softwares/roles/hadoop/dns`
do
 echo $i
 echo $i >>/opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/slaves
done
sbin/hadoop-daemons.sh start datanode
