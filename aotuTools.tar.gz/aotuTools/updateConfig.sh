#!/bin/bash

# 同步配置
for i in `cat /opt/hadoop/softwares/roles/hosts`
do
 hostname=$i
 echo $hostname
 for f in `cat /opt/hadoop/softwares/updatefiles`
  do  
  scp -r $f $hostname:$f
 done
done


