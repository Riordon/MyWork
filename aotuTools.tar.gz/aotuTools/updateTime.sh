#!/bin/bash

for i in `cat /opt/hadoop/softwares/roles/hosts`
do
 hostname=$i
 ssh -t $hostname "sudo systemctl start chronyd.service;sudo systemctl enable chronyd.service"
done

