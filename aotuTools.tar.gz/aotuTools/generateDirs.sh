#!/bin/bash

for i in {1..7}
do
 hostname="zcloudgpsapp0"$i
 echo $hostname
# ssh -t $hostname "rm -rf /opt/hadoop/bigdata-cluster/* /data/hadoop" 
 ssh -t $hostname "cd /opt/hadoop/bigdata-cluster;mkdir logs pids modules;cd logs;mkdir hadoop hbase zookeeper;sudo mkdir -p /data/hadoop && sudo chown -R htapp:htapp /data/hadoop;cd /data/hadoop;mkdir dfs zookeeper;cd dfs && mkdir nn dn jn;cd /data/hadoop/zookeeper && mkdir data"
done

for i in {5..7}
do
 hostname="zcloudgpsapp0"$i
 myid=`expr $i - 4`
 ssh -t $hostname "echo $myid > /data/hadoop/zookeeper/data/myid"
done

# copy tar
for i in {1..7}
do
 hostname="zcloudgpsapp0"$i
 echo $hostname
 scp /opt/hadoop/softwares/*.gz $hostname:/opt/hadoop/bigdata-cluster/modules/
done

# 解压
for i in {1..7}
do
 hostname="zcloudgpsapp0"$i
 echo $hostname
 ssh -t $hostname "cd /opt/hadoop/bigdata-cluster/modules/;tar zxf hadoop-2.9.1.tar.gz && tar zxf hbase-1.4.8.tar.gz && tar zxf jdk1.8.0_191.tar.gz && tar zxf zookeeper-3.4.12.tar.gz;rm -f hadoop-2.9.1.tar.gz && rm -f hbase-1.4.8.tar.gz && rm -f jdk1.8.0_191.tar.gz && rm -f zookeeper-3.4.12.tar.gz"
done


