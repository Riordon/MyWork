#!/bin/bash

# start
for i in {5..7}
do
 hostname="zcloudgpsapp0"$i
 echo $hostname
 ssh -t $hostname "cd /opt/hadoop/bigdata-cluster/modules/zookeeper-3.4.12;bin/zkServer.sh start"
done

sleep 20s

# status
for i in {5..7}
do
 hostname="zcloudgpsapp0"$i
 echo $hostname
 ssh -t $hostname "cd /opt/hadoop/bigdata-cluster/modules/zookeeper-3.4.12;bin/zkServer.sh status"
done
