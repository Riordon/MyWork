#!/bin/bash

# 同步配置
for i in {1..7}
do
 hostname="zcloudgpsapp0"$i
 echo $hostname
 ssh -t $hostname "rm -rf /opt/hadoop/bigdata-cluster/modules/hbase-1.4.8/conf/conf /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/etc/hadoop/hadoop /opt/hadoop/bigdata-cluster/modules/zookeeper-3.4.12/conf/conf"
done


