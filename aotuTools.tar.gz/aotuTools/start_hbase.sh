#!/bin/bash

cd /opt/hadoop/bigdata-cluster/modules/hbase-1.4.8

# master
> /opt/hadoop/bigdata-cluster/modules/hbase-1.4.8/conf/regionservers
for i in `cat /opt/hadoop/softwares/roles/hbase/masters`
do
 echo $i >> /opt/hadoop/bigdata-cluster/modules/hbase-1.4.8/conf/regionservers
done
bin/hbase-daemons.sh start master
sleep 10s

# regionservers
> /opt/hadoop/bigdata-cluster/modules/hbase-1.4.8/conf/regionservers
for i in `cat /opt/hadoop/softwares/roles/hbase/regionservers`
do
 echo $i >> /opt/hadoop/bigdata-cluster/modules/hbase-1.4.8/conf/regionservers
done
bin/hbase-daemons.sh start regionserver
