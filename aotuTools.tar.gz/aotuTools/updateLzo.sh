#!/bin/bash

for i in `cat /opt/hadoop/softwares/roles/hosts`
do
 hostname=$i
 echo $hostname
 scp /opt/hadoop/softwares/lzo/jars/hadoop-lzo-0.4.21-SNAPSHOT.jar $hostname:/opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/share/hadoop/common/
 scp /opt/hadoop/softwares/lzo/jars/hadoop-lzo-0.4.21-SNAPSHOT.jar $hostname:/opt/hadoop/bigdata-cluster/modules/hbase-1.4.8/lib/
 scp /opt/hadoop/softwares/lzo/libg* $hostname:/opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/lib/native/
done

for i in `cat /opt/hadoop/softwares/roles/hosts`
do
 hostname=$i
 ssh -t $hostname "cd /opt/hadoop/bigdata-cluster/modules/hadoop-2.9.1/share/hadoop/common;rm hadoop-lzo-0.4.20-SNAPSHOT.jar;
 cd /opt/hadoop/bigdata-cluster/modules/hbase-1.4.8/lib;rm hadoop-lzo-0.4.20-SNAPSHOT.jar"
done
