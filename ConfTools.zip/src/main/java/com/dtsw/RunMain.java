package com.dtsw;

import java.io.*;

public class RunMain {
    public static void main(String[] args) throws IOException {
        File file = new File("config/yarn-site");
        InputStreamReader read = new InputStreamReader(new FileInputStream(file));//考虑到编码格式
        BufferedReader bufferedReader = new BufferedReader(read);
        String lineTxt = null;

        BufferedWriter bw = new BufferedWriter(new FileWriter(new File("result/yarn-site.xml")));
        StringBuffer buffer = new StringBuffer();

        // 1 开头
        buffer.append("<?xml version=\"1.0\"?>").append("\n");
        buffer.append("<configuration>").append("\n");

        // 2 实体
        while((lineTxt = bufferedReader.readLine()) != null) {
            buffer.append("\t").append("<property>\n");
            String[] split = lineTxt.split("\\|");
            buffer.append("\t").append("\t").append("<name>").append(split[0]).append("</name>\n");
            buffer.append("\t").append("\t").append("<value>").append(split[1]).append("</value>\n");
            buffer.append("\t").append("</property>").append("\n");
        }

        // 结尾
        buffer.append("</configuration>").append("\n");

        bw.write(buffer.toString());
        bw.flush();
        bw.close();

        bufferedReader.close();
    }
}
