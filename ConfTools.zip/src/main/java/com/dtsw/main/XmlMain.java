package com.dtsw.main;

import com.dtsw.conf.EnvManager;
import com.dtsw.utils.XmlUtils;

import java.io.*;

public class XmlMain {
    public static void main(String[] args) throws IOException {
        File file = new File("config/bigdata/input/" + EnvManager.getString("fileName"));
        InputStreamReader read = new InputStreamReader(new FileInputStream(file));//考虑到编码格式
        BufferedReader bufferedReader = new BufferedReader(read);
        String lineTxt = null;

        BufferedWriter bw = new BufferedWriter(new FileWriter(new File("config/bigdata/output/" + EnvManager.getString("fileName") + ".xml")));

        XmlUtils xmlUtils = new XmlUtils();
        while((lineTxt = bufferedReader.readLine()) != null) {
            String[] split = lineTxt.split("\\|");
            xmlUtils.addbody(split[0], split[1]);
        }

        bw.write(xmlUtils.toString());
        bw.flush();
        bw.close();

        read.close();
        bufferedReader.close();
    }
}
