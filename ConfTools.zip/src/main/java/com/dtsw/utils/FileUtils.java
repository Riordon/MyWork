package com.dtsw.utils;

import java.io.*;

public class FileUtils {


    public static void main(String[] args) throws IOException {

    }
}
