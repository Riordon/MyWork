package com.dtsw.utils;

import com.dtsw.conf.MBeanManager;
import com.sun.jmx.mbeanserver.JmxMBeanServer;

import javax.management.*;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeMap;

public class CollectUtils {

    public static void main(String[] args) throws IOException, MalformedObjectNameException, AttributeNotFoundException, MBeanException, ReflectionException, InstanceNotFoundException, IntrospectionException {

        String[] hosts = MBeanManager.getString("hosts").split("\\|");
        String[] ports = MBeanManager.getString("ports").split("\\|");
        if (hosts.length != ports.length) {
            System.out.println("please check params length");
            return;
        }

        StringBuffer buffer = new StringBuffer();
        StringBuffer buffer2 = new StringBuffer();
        BufferedWriter bw = new BufferedWriter(new FileWriter(new File("config\\jmx\\tmp\\query")));
        BufferedWriter bw2 = new BufferedWriter(new FileWriter(new File("config\\jmx\\tmp\\" + MBeanManager.getString("srv"))));
        int index= 0;
        for (int i = 0; i < hosts.length; i++) {
            JMXServiceURL url = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://" + hosts[i] + ":" + ports[i] + "/jmxrmi");
            JMXConnector connector = JMXConnectorFactory.connect(url);
            MBeanServerConnection mBeanServerConnection = connector.getMBeanServerConnection();
            Set<ObjectName> objectNames = mBeanServerConnection.queryNames(null, null);
            for (ObjectName objectName : objectNames) {
                if (!objectName.toString().contains(MBeanManager.getString("filter"))) continue;

                String queryName = "query" + index++;
                buffer2.append(queryName).append(",");
                buffer.append(queryName).append("=").append(objectName.toString()).append("|");
                MBeanInfo mBeanInfo = mBeanServerConnection.getMBeanInfo(new ObjectName(objectName.toString()));
                MBeanAttributeInfo[] attributes = mBeanInfo.getAttributes();
                for (int j = 0; j < attributes.length; j++) {
                    String name = attributes[j].getName();
                    if (name.contains("tag.")) continue;

                    buffer.append(name).append(",");
                }

                buffer.replace(buffer.length()-1, buffer.length(), "|");
                String canonicalName = objectName.getCanonicalName();
                String tableName = designTableName(canonicalName);
                buffer.append(tableName).append("\n");

                bw.write(buffer.toString());
                bw.flush();
                buffer.setLength(0);
            }

            buffer2.replace(buffer2.length()-1, buffer2.length(), "").append("\n");
            bw2.write(hosts[i] + "|" + ports[i] + "|" + buffer2.toString());
            bw2.flush();
            buffer2.setLength(0);
        }

        bw.close();
        bw2.close();
    }

    private static String designTableName(String canonicalName) {
        TreeMap<String, String> kvs = new TreeMap<>();
        String[] split = canonicalName.split("\\:");
        String[] split2 = split[1].split("\\,");
        for (int i = 0; i < split2.length; i++) {
            String[] split3 = split2[i].split("\\=");
            kvs.put(split3[0], split3[1].split("\\-")[0]);
        }

        String prefix = "";
        String suffix = "_";
        String service = "";
        String name = "";

        for (String k : kvs.keySet()) {
            if (k.equals("service")) {
                service = kvs.get(k);
            } else if  (k.equals("name")) {
                name = kvs.get(k);
            } else {
                suffix += kvs.get(k) + "_";
            }
        }

        prefix = service + "_" + name;
        if (prefix.equals("_")) prefix = "";

        suffix = suffix.substring(0 , suffix.length()-1);
        if (suffix.equals("_")) suffix = "";

        return prefix + suffix;
    }
}
