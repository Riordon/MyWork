package com.dtsw.utils;

import com.dtsw.conf.MBeanManager;
import com.dtsw.conf.QueryManager;
import com.dtsw.conf.SinkDBManager;
import com.dtsw.utils.jmxBase.OutputWriter;
import com.dtsw.utils.jmxBase.Query;
import com.dtsw.utils.jmxBase.Server;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class JmxUtils {
    private List<Server> servers = new ArrayList<Server>();

    public List<Server> getServers() {
        return servers;
    }

    public void setServers(List<Server> servers) {
        this.servers = servers;
    }

    public String toString() {
        return "{\n" +
                "\"servers\" : " + getServers() + "\n" +
                "}\n";
    }

    public static void main(String[] args) throws IOException {
        JmxUtils jmxUtils = new JmxUtils();

        List<Server> servers = new ArrayList<Server>();

        File file = new File("config/jmx/" + MBeanManager.getString("srv"));
        InputStreamReader read = new InputStreamReader(new FileInputStream(file));
        BufferedReader bufferedReader = new BufferedReader(read);
        String lineTxt = null;
        while((lineTxt = bufferedReader.readLine()) != null) {
            String[] split = lineTxt.split("\\|");
            Server server = new Server();
            server.setHost(split[0]);
            server.setPort(split[1]);

            ArrayList<Query> queries = getQueries(split[2]);
            server.setQueries(queries);

            servers.add(server);
        }

        jmxUtils.setServers(servers);
        System.out.println(jmxUtils.toString());
    }

    private static ArrayList<Query> getQueries(String qs) {
        String[] qNames = qs.split("\\,");

        ArrayList<Query> queries = new ArrayList<>();

        for (int i = 0; i < qNames.length; i++) {
            String qText = QueryManager.getString(qNames[i]);
            String[] split = qText.split("\\|");

            Query query = new Query();
            query.setObj(split[0]);
            query.setAttr(split[1]);
            query.setResultAlias(split[2]);
            List<OutputWriter> outputWriters = getOutputWriters();
            query.setOutputWriters(outputWriters);
            queries.add(query);
        }

        return queries;
    }

    private static List<OutputWriter> getOutputWriters() {
        List<OutputWriter> outputWriters = new ArrayList<OutputWriter>();
        OutputWriter outputWriter = new OutputWriter();
        outputWriter.setTclass("com.googlecode.jmxtrans.model.output.InfluxDbWriterFactory");
        outputWriter.setUrl(SinkDBManager.getString("url"));
        outputWriter.setUsername(SinkDBManager.getString("username"));
        outputWriter.setPassword(SinkDBManager.getString("password"));
        outputWriter.setDatabase(SinkDBManager.getString("database"));
        outputWriters.add(outputWriter);
        return outputWriters;
    }
}
