package com.dtsw.utils;

import java.util.ArrayList;
import java.util.List;

public class XmlUtils {
    private String head;
    private String body;
    private String tail;

    public XmlUtils() {
        head = "<?xml version=\"1.0\"?>\n<?xml-stylesheet type=\"text/xsl\" href=\"configuration.xsl\"?>\n" + "<configuration>\n";
        body = "";
        tail = "</configuration>";
    }

    public void addbody(String name, String value) {
        StringBuffer buffer = new StringBuffer();
        buffer.append("\t<property>\n");
        buffer.append("\t\t<name>" + name + "</name>\n");
        buffer.append("\t\t<value>" + value + "</value>\n");
        buffer.append("\t</property>\n");
        body += buffer.toString();
    }

    public String toString() {
        return head + body + tail;
    }

    public static void main(String[] args) {
        XmlUtils xmlUtils = new XmlUtils();
        for (int i = 0; i < 10; i++) {
            xmlUtils.addbody("name"+i, "val"+i);
        }
        System.out.println(xmlUtils.toString());
    }
}
