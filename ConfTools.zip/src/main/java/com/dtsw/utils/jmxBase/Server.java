package com.dtsw.utils.jmxBase;

import java.util.ArrayList;
import java.util.List;

public class Server {
    private String port;
    private String host;
    private List<Query> queries = new ArrayList<Query>();

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = "\"" + port + "\"";
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = "\"" + host + "\"";
    }

    public List<Query> getQueries() {
        return queries;
    }

    public void setQueries(List<Query> queries) {
        this.queries = queries;
    }

    public String toString() {
        return "{\n" +
                "\"host\" : " + getHost() + ",\n" +
                "\"port\" : " + getPort() + ",\n" +
                "\"queries\" : " + getQueries() + "\n" +
                "}\n";
    }

    public static void main(String[] args) {
        Server server = new Server();
        server.setHost("172.18.2.37");
        server.setPort("40001");
        ArrayList<Query> queries = new ArrayList<>();
        Query query = new Query();
        query.setObj("org.apache.ZooKeeperService:name0=ReplicatedServer_id*");
        query.setAttr("QuorumSize,BlocksRead,BlocksWritten");
        query.setResultAlias("QuorumSize");
        List<OutputWriter> outputWriters = new ArrayList<OutputWriter>();
        OutputWriter outputWriter = new OutputWriter();
        outputWriter.setTclass("com.googlecode.jmxtrans.model.output.InfluxDbWriterFactory");
        outputWriter.setUrl("http://172.18.2.29:8086/");
        outputWriter.setUsername("root");
        outputWriter.setPassword("root123");
        outputWriter.setDatabase("zkJmx");
        outputWriters.add(outputWriter);
        query.setOutputWriters(outputWriters);
        queries.add(query);

        server.setQueries(queries);

        System.out.println(server.toString());
    }
}
