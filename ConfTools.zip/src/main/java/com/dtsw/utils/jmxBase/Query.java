package com.dtsw.utils.jmxBase;

import java.util.ArrayList;
import java.util.List;

public class Query {
    private String obj;
    private String attr;
    private String resultAlias;
    private List<OutputWriter> outputWriters = new ArrayList<OutputWriter>();


    public String getObj() {
        return obj;
    }

    public void setObj(String obj) {
        this.obj = "\"" + obj + "\"";
    }

    public String getAttr() {
        return attr;
    }

    public void setAttr(String attr) {
        String tmpStr = "[";
        String[] split = attr.split("\\,");
        for (int i = 0; i < split.length; i++) {
            tmpStr += "\"" + split[i] + "\",";
        }

        this.attr = tmpStr.substring(0, tmpStr.length()-1) + "]";
    }

    public String getResultAlias() {
        return resultAlias;
    }

    public void setResultAlias(String resultAlias) {
        this.resultAlias = "\"" + resultAlias + "\"";
    }

    public List<OutputWriter> getOutputWriters() {
        return outputWriters;
    }

    public void setOutputWriters(List<OutputWriter> outputWriters) {
        this.outputWriters = outputWriters;
    }

    public String toString() {
        return "{\n" +
                "\"obj\" : " + getObj() + ",\n" +
                "\"attr\" : " + getAttr() + ",\n" +
                "\"resultAlias\" : " + getResultAlias() + ",\n" +
                "\"outputWriters\" : " + getOutputWriters() + "\n" +
                "}\n";
    }

    public static void main(String[] args) {
        Query query = new Query();
        query.setObj("org.apache.ZooKeeperService:name0=ReplicatedServer_id*");
        query.setAttr("QuorumSize,BlocksRead,BlocksWritten");
        query.setResultAlias("QuorumSize");

        List<OutputWriter> outputWriters = new ArrayList<OutputWriter>();
        OutputWriter outputWriter = new OutputWriter();
        outputWriter.setTclass("com.googlecode.jmxtrans.model.output.InfluxDbWriterFactory");
        outputWriter.setUrl("http://172.18.2.29:8086/");
        outputWriter.setUsername("root");
        outputWriter.setPassword("root123");
        outputWriter.setDatabase("zkJmx");
        outputWriters.add(outputWriter);

        query.setOutputWriters(outputWriters);

        System.out.println(query.toString());

    }
}
