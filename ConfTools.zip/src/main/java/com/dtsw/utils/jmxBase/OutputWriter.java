package com.dtsw.utils.jmxBase;

public class OutputWriter {
    private String Tclass;
    private String url;
    private String username;
    private String password;
    private String database;

    public String getTclass() {
        return Tclass;
    }

    public void setTclass(String tclass) {
        Tclass = "\"" + tclass + "\"";
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = "\"" + url + "\"";
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = "\"" + username + "\"";
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = "\"" + password + "\"";
    }

    public String getDatabase() {
        return database;
    }

    public void setDatabase(String database) {
        this.database = "\"" + database + "\"";
    }

    public String toString() {
        return "{\n" +
                "\"@class\" : " + getTclass() + ",\n" +
                "\"url\" : " + getUrl() + ",\n" +
                "\"username\" : " + getUsername() + ",\n" +
                "\"password\" : " + getPassword() + ",\n" +
                "\"database\" : " + getDatabase() + "\n" +
                "}\n";
    }

    public static void main(String[] args) {
        OutputWriter outputWriter = new OutputWriter();
        outputWriter.setTclass("com.googlecode.jmxtrans.model.output.InfluxDbWriterFactory");
        outputWriter.setUrl("http://172.18.2.29:8086/");
        outputWriter.setUsername("root");
        outputWriter.setPassword("root123");
        outputWriter.setDatabase("zkJmx");

        System.out.println(outputWriter.toString());
    }
}
