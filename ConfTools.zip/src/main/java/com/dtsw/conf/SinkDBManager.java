package com.dtsw.conf;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class SinkDBManager {
    private static Properties prop = new Properties();
    static {
        InputStream inputStream = SinkDBManager.class.getClassLoader().getResourceAsStream("jmx/input/sinkdb");
        try {
            prop.load(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getString(String key) { return prop.getProperty(key); }

    public static Integer getInteger(String key) { return Integer.valueOf(prop.getProperty(key)); }

    public static Boolean getBoolean(String key) {
        return Boolean.valueOf(prop.getProperty(key));
    }

    public static Long getLong(String key) {
        return Long.valueOf(prop.getProperty(key));
    }

    public static Double getDouble(String key) {
        return Double.valueOf(prop.getProperty(key));
    }

    public static void main(String[] args) {
        System.out.println(SinkDBManager.getString("username"));
    }
}
